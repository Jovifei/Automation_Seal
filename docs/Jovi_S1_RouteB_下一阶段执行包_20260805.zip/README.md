# 使用说明

先读交接文档，再把完整 Prompt 交给执行 Agent。若当前 Agent 曾参与 Route B 工件生成，不允许其自己做最终独立审核。
