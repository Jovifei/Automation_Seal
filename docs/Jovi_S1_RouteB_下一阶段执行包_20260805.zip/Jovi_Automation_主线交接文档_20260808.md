# Jovi Automation 主线交接文档
版本：2026-08-08

## 0. 核心结论

当前项目没有偏离最终方向，但近期明显“治理证据优先、产品落地滞后”。

从现在起必须坚持：

> 先完成，再完美；先完成首个可销售 Modbus RTU 诊断工具包，再优化自动化和治理。

### 主线
S1 最终独立审核
→ Manifest-only APPLY
→ Post-Apply Audit
→ S1 Close
→ Gate A.P
→ Modbus RC
→ Windows UAT
→ Pilot
→ 首个可销售 V1

### 优化线
以下不得阻塞主线：
- Track I
- docs 进一步美化
- 自动部署
- 自动发布
- 高级 Hook
- CI/CD
- 自动客服
- 多产品扩展
- 高级指标体系

---

## 1. 已完成

### 产品
- Modbus Alpha 已存在。
- 当前核心单元测试 12/12 PASS。
- Alpha ZIP 与源码 12/13 差异已定位。
- parser.py 差异已多次验证为 warning 文本格式换行差异，没有发现业务语义变化。
- Modbus RC Candidate 已有准备材料。

### S1 / Route B
- Route B 人类决定已经形成。
- 10 项 current SHA 已冻结。
- T0 通过。
- A/B Shadow 已完成。
- Rollback Drill 已完成。
- 当前回归已覆盖：
  - Security semantics 20/20
  - S2A2 24/24
  - S1 34/34 ×2
  - S2A1 42/42
  - Batch B 21/21
  - Hook subset 9/9
  - Canonical Hook 28/28
  - Modbus Alpha 12/12
- Hook 当前结论：
  `CANDIDATE_SEMANTICS_VERIFIED_BUT_UNTRUSTED`
- Hook 仍应保持：
  `DO_NOT_TRUST`
- 独立评审包已经形成。
- 多轮零漂移/回滚证据已形成。

### 工程与文档
- docs 已建立 6 类索引。
- 多个 comet change 已归档。
- STATUS、review-queue、控制证据持续更新。
- 未自动操作闲鱼真实业务。
- 未做未经批准的真实 APPLY。

---

## 2. 当前真正卡点

现在不是“代码不会写”，而是 S1 没有最终闭环。

### Blocker A：正式 Manifest
10 个目标字节已经存在，但 FRAMEWORK_MANIFEST.sha256 仍没有完成正式受控绑定。

正确路径：
1. 真正独立审核 Route B 最新最终工件；
2. Jovi 精确决定 Candidate Manifest；
3. Manifest-only APPLY；
4. APPLY 后全回归；
5. Post-Apply 独立审核。

### Blocker B：Hook
Hook 仍为 DO_NOT_TRUST。

当前不应为了状态变绿而直接 TRUST。

如果首发产品不依赖 Hook，优先：
`DO_NOT_TRUST_AND_KEEP_DISABLED`

如果 S1 框架强制要求 Hook 信任，才单独做 Hook Final Audit。

### Blocker C：独立性
同一父任务里的子 Agent 审核不等于最终独立审核。

只要审核后又修改工件，原审核自动失效。

---

## 3. 对最近 Agent 计划的审核

### 做对的
- 没有越权创建 approval。
- 没有强行 TRUST Hook。
- 没有真实发布。
- parser 差异继续做了实证。
- 准备了 Gate A、目标机核查和 Track P/I 材料。
- 文档治理采用索引而没有破坏硬编码路径。
- 保持 fail-closed。

### 必须纠偏
1. 不要优先 Track I。
2. 不要在 S1 未闭环前先跑 Gate A.P/I。
3. 目标机 NOT_VERIFIED 主要属于 RC/UAT，不应全部阻塞 S1。
4. 停止新增非必要治理 Framework、Track、状态体系和文档分类。

---

# 4. 长期分阶段计划

## Phase 1 — S1 最终闭环
### 实施
- 全新会话独立审核最新 Route B 工件。
- PASS 后由 Jovi 决定 Candidate Manifest。
- Manifest-only APPLY。
- APPLY 后完整回归。
- 新会话 Post-Apply Audit。
- 精确处理 HOOK_UNTRUSTED。
- 正式关闭 S1。

### 验收
- Manifest 21 项正确。
- 10 项绑定审核通过的 current SHA。
- 非批准条目 0 变化。
- 无新增回归失败。
- Post-Apply Audit PASS。
- S1 blocker 清零或有正式延期决定。

## Phase 2 — Gate A.P
### 实施
- 只生成首发产品需要的 Gate A.P。
- Jovi 本人审核。
- Track I 默认延期。

### 验收
- Gate A.P 合法。
- Track P 获批准。
- Track I=DEFERRED 或单独计划。

## Phase 3 — Modbus RC
### 实施
- 统一 parser.py 规范字节。
- 两次独立构建相同 ZIP SHA。
- 冻结 RC 文件清单。
- 完成 INSTALL、QUICK_START、USER_GUIDE、TROUBLESHOOTING、CHANGELOG、LICENSE、VERSION。
- 准备 Modbus 正常与错误示例。
- 准备最小安装流程。

### 验收
- 测试 PASS。
- 双构建 SHA 一致。
- 干净 Windows 可安装。
- 用户 10 分钟内完成第一个诊断。
- 不依赖开发机专有路径。

## Phase 4 — Windows UAT
### 实施
- 解压
- 安装
- 启动
- 示例
- 实际串口/Modbus
- 错误场景
- 导出
- 重装
- 卸载/清理

### 验收
- 安装成功率 100%。
- 核心流程不需改源码。
- 历史 NOT_VERIFIED 逐项关闭。

## Phase 5 — Pilot
### 实施
5–10 名真实用户：
- 嵌入式
- 自动化
- PLC/Modbus 调试
- 工程师/学生

记录：
- 安装成功
- 核心诊断成功
- 使用耗时
- Bug
- 缺失功能
- 付费意愿

### 验收
建议最低：
- ≥80% 安装成功
- ≥70% 完成核心任务
- ≥60% 认为有价值
- 至少 3 个明确付费信号

## Phase 6 — 首个可销售 V1
交付物：
- 最终 ZIP/installer
- SHA256
- VERSION
- QUICK START
- USER GUIDE
- LICENSE
- CHANGELOG
- 示例
- FAQ
- SUPPORT POLICY
- RELEASE NOTES

闲鱼仅作为独立 Adapter，发布、回复、交易、交付、退款仍由 Jovi 控制。

## Phase 7 — 商业验证
记录：
- 浏览→咨询
- 咨询→购买
- 安装成功率
- 支持工单
- 退款率
- 用户愿付价格

## Phase 8 — 优化与自动化
真实用户出现后再投入：
- Track I
- 自动打包
- 自动交付
- 自动客服辅助
- 指标看板
- 多产品模板
- CI/CD
- 渠道自动化

---

# 5. 当前短期四个 Sprint

## Sprint 1 — Final Independent Audit
目标：取得真正独立 PASS/FAIL。
验收：PASS 且 0 Critical/High。

## Sprint 2 — Manifest-only APPLY
前提：Sprint 1 PASS + Jovi 精确批准。
验收：Post-Apply Audit PASS。

## Sprint 3 — S1 Close + Gate A.P
实施：处理 Hook、关闭 S1、生成 Gate A.P、Track I 延期。
验收：Track P READY。

## Sprint 4 — Modbus RC + UAT
实施：RC 双构建、安装、UAT、文档、示例。
验收：RC READY FOR PILOT。

---

# 6. 优先级

## P0
1. S1 Final Independent Audit
2. Manifest-only APPLY
3. S1 Close
4. Gate A.P
5. Modbus RC
6. Windows UAT
7. Pilot

## P1
- Hook TRUST（仅在 S1 强依赖时）
- UI/UX
- 支持文档
- 更多 Modbus 示例

## P2
- Track I
- 自动部署
- 自动渠道
- 高级指标
- docs 美化

---

# 7. 每轮 Agent 必答

1. 当前主线阶段
2. 本轮目标
3. 实际完成
4. 未完成
5. 新发现
6. 是否产生真实产品价值
7. 是否只增加治理文档
8. 当前 blocker
9. 是否允许下一阶段
10. 下一唯一任务
11. 总体产品进度
12. 禁止自动执行的动作

---

# 8. 进度计算

禁止用报告数量提高进度。

建议：
- S1治理关闭：15%
- Gate A.P：10%
- Modbus RC：25%
- Windows UAT：15%
- Pilot：15%
- 商业交付包：10%
- 真实销售验证：10%

当前总体落地成熟度建议：
约 42–48%。
